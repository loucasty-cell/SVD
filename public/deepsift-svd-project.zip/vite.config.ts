import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  optimizeDeps: {
    exclude: ['@google/genai', 'express']
  },
  server: {
    host: '0.0.0.0',
    port: 3000,
    hmr: false,
  },
});
